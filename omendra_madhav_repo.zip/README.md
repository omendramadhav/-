# Omendra Madhav - Personal Website

यह मेरा पर्सनल पोर्टफोलियो है।  
इसे फ्री में GitHub Pages या Netlify पर होस्ट किया जा सकता है।  

## 🚀 Live Setup Guide
- GitHub Pages → Settings > Pages > Branch: main
- Netlify → Drag & Drop the site folder

© 2025 Omendra Madhav
